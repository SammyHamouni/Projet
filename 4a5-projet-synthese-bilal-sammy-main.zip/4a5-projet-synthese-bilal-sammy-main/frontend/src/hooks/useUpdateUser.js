import { useState } from "react";
import { useAuthContext } from "./useAuthContext";

export const useUpdateUser = () => {
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const { dispatch } = useAuthContext();

  const updateUser = async (nom, prenom, email, password) => {
    setIsLoading(true);
    setError(null);

    try {
      const userId = localStorage.getItem("_id");

      const response = await fetch(
        process.env.REACT_APP_BACKEND_URL + `users/${userId}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ nom, prenom, email, password }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message);
      }

      const data = await response.json();
      dispatch({ type: "UPDATE_USER", payload: data });
      setIsLoading(false);
      return data;
    } catch (err) {
      setIsLoading(false);
      setError(err.message);
    }
  };

  return { updateUser, isLoading, error };
};
