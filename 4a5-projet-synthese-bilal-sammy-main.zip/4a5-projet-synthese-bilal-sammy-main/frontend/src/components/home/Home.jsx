import "./Home.css";

const Home = () => {
  return <h3 id="slogan">Bienvenue à bord de SaharaWings ✈️</h3>;
};

export default Home;
