const express = require("express");
const { check } = require("express-validator");

const {
  getPassagers,
  createPassager,
} = require("../controllers/passagerController");

const router = express.Router();

router.get("/", getPassagers);

router.post(
  "/",
  [
    check("nom").not().isEmpty().isLength({ min: 3 }),
    check("prenom").not().isEmpty().isLength({ min: 3 }),
    check("age").isInt({ min: 0 }),
    check("type").isIn(["adulte", "enfant", "bebe"]),
  ],
  createPassager
);

module.exports = router;
