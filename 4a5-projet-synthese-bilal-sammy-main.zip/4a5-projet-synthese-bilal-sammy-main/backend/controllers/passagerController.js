const Passager = require("../models/passagerModel");
const Vol = require("../models/volModel");
const { validationResult } = require("express-validator");

const getPassagers = async (req, res) => {
  const passagers = await Vol.find({});
  res.status(201).json(passagers);
};

const createPassager = async (req, res) => {
  const validationErrors = validationResult(req);
  if (!validationErrors.isEmpty()) {
    console.log(validationErrors);
    return res.status(422).json({ error: "Données invalides" });
  }

  const { vol, nom, prenom, age, type } = req.body;

  try {
    const volData = await Vol.findById(vol);
    if (!volData) {
      return res.status(404).json({ error: "Vol non trouvé!" });
    }

    if (
      (type === "bebe" && (age < 0 || age > 2)) ||
      (type === "enfant" && (age < 3 || age > 12)) ||
      (type === "adulte" && age < 13)
    ) {
      return res.status(400).json({
        error: `L'âge ne correspond pas au type de passager ${type}.`,
      });
    }

    const nbrPassagers = await Passager.countDocuments({ vol, type });
    if (nbrPassagers >= volData[type + "s"]) {
      return res
        .status(400)
        .json({ error: `Limite de passagers ${type} atteinte!` });
    }

    const passager = await Passager.create({
      vol,
      nom,
      prenom,
      age,
      type,
    });

    res.status(201).json(passager);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  getPassagers,
  createPassager,
};
