const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const passagerSchema = new Schema({
  vol: { type: Schema.Types.ObjectId, ref: "Vol" },
  nom: { type: String, required: true },
  prenom: { type: String, required: true },
  age: { type: Number, required: true },
  type: { type: String, enum: ["adulte", "enfant", "bebe"], required: true },
});

module.exports = mongoose.model("Passager", passagerSchema);
