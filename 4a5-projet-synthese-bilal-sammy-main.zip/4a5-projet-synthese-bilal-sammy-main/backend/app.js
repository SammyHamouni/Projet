require("dotenv").config();

const cors = require("cors");
const express = require("express");
const mongoose = require("mongoose");
const volRoutes = require("./routes/vols");
const userRoutes = require("./routes/users");
const passagerRoutes = require("./routes/passagers");

const app = express();

const PORT = process.env.PORT || 4000;
const MONG_URI =
  process.env.MONG_URI ||
  "mongodb+srv://lahloubilal05:SaharaWings@saharawings.z0lvj9h.mongodb.net/?retryWrites=true&w=majority&appName=SaharaWings";

app.use(express.json());

app.use(cors());

app.use((req, res, next) => {
  console.log(req.path, req.method);
  next();
});

app.use("/api/vols", volRoutes);
app.use("/api/users", userRoutes);
app.use("/api/passagers", passagerRoutes);

mongoose
  .connect(MONG_URI)
  .then(() => {
    app.listen(PORT, () => {
      console.log("Connected to database and server is running on port", PORT);
    });
  })
  .catch((error) => {
    console.log(error);
  });
