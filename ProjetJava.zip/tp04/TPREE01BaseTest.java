package shamouni.tp04;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TPREE01BaseTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
