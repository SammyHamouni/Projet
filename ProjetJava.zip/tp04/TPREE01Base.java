package shamouni.tp04;
import java.util.Scanner;

import java.io.*;
import java.util.*;

public class TPREE01Base {

	public static void main(String[] args) {
		Scanner clavier = new Scanner(System.in);
		// Declaration et initialisation de dict : tableau de 40000 String
		String[] dict = new String [40000];
		// il contient l'ensemble des mots du dictionnaire
		// Declaration et initialisation de motsGrille : tableau de 50 String
		String[] motsGrille = new String[50];
		// il contient les mots ajoutes dans la grille
		// Declaration et initialisation de grille : tableau de 9 lignes et 12 colonnes
		// de caracteres
		char[][] grille = new char[9][12];
		// il contient les differents caracteres inscrits dans la grille
		// Declaration et initialisation de nbMotsDict : entier
		int nbMotsDict = 0;
		// il represente le nombre de mots dans le dictionnaire
		// Declaration et initialisation de nbMotsGrille : entier
		int nbMotsGrille = 0;
		// il represente le nombre de mots ajoutes dans la grille
		// Declaration de la chaine ligneCommande pour stocker la commande de l'usager
		String ligneCommande = "";
		// Declaration de la variable de type caractere nommee commande
		char commande;
		// Appel de la fonction lireDictionnaire et recuperation du nombre de mots lus
		nbMotsDict = lireDictionnaire(dict);
		// Affichage du nombre de mots lus dans le dictionnaire
		System.out.println(nbMotsDict);
		// Tri du dictionnaire en ordre alphabetique a l'aide de la fonction triSel
		triSel(dict, nbMotsDict);
		// BOUCLE PRINCIPALE
		do {
		// Appeler afficheGrille et afficheMots
			afficheGrille(grille);
			afficheMots(motsGrille, nbMotsGrille);
		// Afficher l'invite de commande: "[aercsq] > "
			System.out.println();
			System.out.println("[aercsq] >"); 
		// Lire la commande de l'usager dans la variable ligneCommande
			ligneCommande=clavier.next();
		// Extraire le premier caractere dans la variable commande
			commande=ligneCommande.charAt(0);
		// SELON commande
			switch(commande) {
			// SI a ALORS appeler commandeAjout et recuperer le nbMotsGrille
			case 'a' :
				nbMotsGrille=commandeAjout(ligneCommande, grille, dict, nbMotsDict, motsGrille, nbMotsGrille);
				break;
				// SI e ALORS appeler commandeEnlever
			case 'e' : 
				commandeEnlever(ligneCommande,grille);
				break;
				// SI r ALORS appeler commandeRetirer et recuperer le nbMotsGrille
			case 'r' :
				nbMotsGrille=commandeRetirer(ligneCommande, motsGrille, nbMotsDict);
				break;
				// SI c ALORS appeler commandeCompleter
			case 'c' :
				commandeCompleter(ligneCommande, grille);
				break;
				// SI s ALORS appeler commandeSauvegarder
			case 's' :
				commandeSauvegarder(ligneCommande, grille, motsGrille, nbMotsGrille);
				break;
				// SI q ALORS ne rien faire
			case 'q' :
				break;
				// SINON afficher "Commande invalide. Votre commande doit debuter par [aercsq]."
			 default :
				System.out.println("Commande invalide. Votre commande doit debuter par [aercsq].");
			}
		
		
		
		
		
	
		
		// BOUCLE PRINCIPALE TANT QUE commande n'est pas q
		} while (commande!= 'q');
		// Afficher "Au revoir"
		System.out.println("Au revoir");
	}

	// TODO: Javadoc
	// TODO: Tests unitaires
	public static int commandeAjout(String ligneCommande, char[][] grille, String[] dict, int nbDict, String[] mots,
			int nbMots) {
		// Fonction qui permet d'ajouter un mot dans la grille.
		// Verifier la syntaxe de ligneCommande -> a:l,c,d,mot
// 		l : numero de ligne de 1 a 9
		// c : numero de colonne de 1 a 12
		// d : direction E, NE, N, NO, O, SO, S ou SE
		// mot : chaine de caracteres minuscules (a-z)
		// Si la syntaxe est correcte
		if (ligneCommande.matches("a:[1-9],([1-9]|1[0-2]),(N|NE|E|SE|S|SO|O|NO),[a-z]{1,}")) {
//			separer la commande suivant le : en utilisant la virgule comme separateur
			String[] tableau = ligneCommande.split(",");

//		SI le mot existe dans le dictionnaire (utiliser rechercheBin pour verifier)
			if (rechercheBin(dict, nbDict, tableau[3]) != -1) {
				// SI il reste de la place dans le tableau mots
				if (mots.length > nbMots) {
					// Initialiser posLigne et posCol aux positions inscrites dans la commande
					String posLigne = tableau[0].substring(2); // Pour le numéro de ligne (l)
					String posCol = tableau[1]; // pour le numéro de colonne(c)
					// Utiliser Integer.parseInt pour faire la conversion
					int posL = Integer.parseInt(posLigne);
					int posC = Integer.parseInt(posCol);
//		Initialiser dirLigne et dirCol pour savoir dans quelle direction
					int dirLigne = 0;
					int dirCol = 0;
//		ajouter le mot.  Si la direction contient
//					N alors dirLigne = -1; S alors dirLigne = 1
//					E alors dirCol = 1; O alors dirCol = -1
					switch (tableau[2]) {
					case "N":
						dirLigne = -1;
						break;

					case "S":
						dirLigne = 1;
						break;

					case "E":
						dirCol = 1;
						break;

					case "O":
						dirCol = -1;
						break;

					case "NE":
						dirLigne = -1;
						dirCol = 1;
						break;

					case "NO":
						dirLigne = -1;
						dirCol = -1;
						break;

					case "SO":
						dirLigne = 1;
						dirCol = -1;
						break;

					case "SE":
						dirLigne = 1;
						dirCol = -1;
						break;

					}

					// Parcourir le tableau a partir de posLigne,posCol et
					// incrementer de dirLigne et dirCol afin de verifier si chaque lettre du mot
					// a ajouter se trouve dans une case vide ou dans une case contenant deja la
					// meme lettre. Verifier aussi si on depasse les limites du tableau.
					boolean test = true;
					for (int i = 0; i < tableau[3].length(); i++) {

						if (posL < 0 || posL >= grille.length || posC < 0 || posC >= grille[0].length || grille[posL][posC] != 0 && grille[posL][posC] != tableau[3].toUpperCase().charAt(i)) {
							test = false;
							break;
						}

						posLigne += dirLigne;
						posCol += dirCol;
					}

					if (test == true) {
//				SI aucun conflit ou depassement n'est detecte
						// Reinitialiser posLigne,posCol
						posL = Integer.parseInt(posLigne);
						posC = Integer.parseInt(posCol);
//					Ajouter chaque lettre du mot en majuscule dans la grille
						// Ajouter le mot dans le tableau mots (fonction ajout)
						for (int i = 0; i < tableau[3].length(); ++i) {
							grille[posL][posC] = tableau[3].toUpperCase().charAt(i); // En majuscule
							posL += dirLigne;
							posC += dirCol;

						}

						nbMots = ajout(mots, nbMots, tableau[3]);
//				SINON (conflit)
						// Afficher "Conflit entre deux mots ou le mot depasse la grille."
					} else {
						System.out.println("Erreur");

					}

				}

			}

		}

		// SINON (capacite mots)
		// Afficher "Nombre de mots maximal atteint."
		// SINON (pas dans dictionnaire)
		// Afficher "Mot invalide : " + mot
		// SINON (syntaxe invalide)
		// Afficher "Ecrire \"a:l,c,d,mot\" pour ajouter un mot."
		// Retourner le nouveau nombre de mots dans le tableau mots
		return nbMots;
	}

	// TODO: Javadoc
	// TODO: Tests unitaires
	public static void commandeEnlever(String ligneCommande, char[][] grille) {
		// Fonction qui efface un caractere de la grille
		// Verifier la syntaxe de ligneCommande -> e:l,c
		// l : numero de ligne de 1 a 9
		// c : numero de colonne de 1 a 12
		if (ligneCommande.matches("e:[1-9],[1-9]|1[0-2]")) {
			String tableau[];
			tableau = ligneCommande.split(",");
			String posLigne, posCol;
//	 		SI la syntaxe est correcte
			// Convertir la ligne et la colonne en int en utilisant Integer.parseInt
			int ligne = Integer.parseInt(tableau[1]);
			int colonne = Integer.parseInt(tableau[0]);
			// Mettre le caractere correspondant a 0 dans la grille
			grille[ligne][colonne] = 0;
//	 		SINON
		} else {
			// Afficher "Ecrire \"e:l,c\" pour enlever le caractere a la position l,c ."
			System.out.println("Ecrire \\\"e:l,c\\\" pour enlever le caractere a la position l,c .");
		}

	}

	// TODO: Javadoc
	// TODO: Tests unitaires
	public static int commandeRetirer(String ligneCommande, String[] mots, int nbMots) {
		int nbMot = 0;
		// Fonction qui permet d'enlever un mot de la liste des mots inclus dans la
		// grille
		// Verifier la syntaxe de ligneCommande -> r:mot
		// mot : chaine de caracteres minuscules (a-z)
		// SI la syntaxe est valide
		if (ligneCommande.matches("r:([A-Z])+")) {
			// Appeler la fonction retrait

			nbMot = retrait(mots, nbMots, ligneCommande);
		}

		// SI aucun mot n'a ete retire
		if (nbMot == nbMots) {
			// Afficher "Mot introuvable"
			System.out.println("Mot introuvable");
		}

		// SINON (syntaxe)
		else {
			// Afficher "Ecrire \"r:mot\" pour retirer \"mot\" de la liste."
			System.out.println("Ecrire \\\"r:mot\\\" pour retirer \\\"mot\\\" de la liste.");
		}

		// Retourner le nouveau nombre de mots dans mots
		return nbMot;
	}

	// TODO: Javadoc
	public static void commandeCompleter(String ligneCommande, char[][] grille) {
		// Fonction qui remplit les trous vides de la grille avec des caracteres
		// aleatoires
		// Declarer et initialiser un tableau de caracteres contenant les lettres de
		// l'alphabet en majuscule (alphabet)
		char alphabet[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
				'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
		// SI la syntaxe est valide (c:)
		if (ligneCommande.matches("c:")) {
			// Parcourir la grille et pour chaque case vide (=0), mettre une lettre
			// majuscule aleatoire. Utiliser (int) (Math.random()*26) pour selectionner
			// l'index de alphabet correspondant a la lettre a inserer
			for (int i = 0; i < grille.length; ++i) {
				for (int j = 0; j < grille[i].length; ++j) {
					int aleatoire = (int) (Math.random() * 26);
					if (grille[i][j] == 0) { // Si c'est vide
						grille[i][j] = (char) alphabet[aleatoire];
					}
				}
			}
			// SINON
		} else {
			// Afficher "Ecrire \"c:\" pour completer la grille."
			System.out.println("Ecrire \\\"c:\\\" pour completer la grille.");
		}

	}

	// TODO: Javadoc
	public static void commandeSauvegarder(String ligneCommande, char[][] grille, String[] mots, int nbMots) {
		// Fonction qui permet de sauvegarder la grille et les mots caches
		// SI la syntaxe est valide (s:)
		if (ligneCommande.matches("s:")) {
			// Appeler la fonction ecrireGrille
			ecrireGrille(grille, mots, nbMots);
		}

		// SINON
		else {
			// Afficher "Ecrire \"s:\" pour sauvegarder."
			System.out.println("Afficher \"Ecrire \\\"s:\\\" pour sauvegarder.");
		}

	}

	// TODO: Javadoc
	public static void afficheGrille(char[][] grille) {
		
		// Afficher la grille a la console sous le format:
		// 1 2 3 4 5 6 7 8 9101112
		System.out.println("1 2 3 4 5 6 7 8 9 101112");
		// 1 _ _ _ _ _ _ _ _ _ _ _ _
				// 2 _ _ _ _ _ _ _ _ _ _ _ _
				// 3 _ _ _ _ _ E _ _ _ _ _ _
				// 4 _ _ _ _ _ T _ _ _ _ _ _
				// 5 _ _ _ _ _ A _ _ _ _ _ _
				// 6 _ _ _ _ _ T _ _ _ _ _ _
				// 7 _ _ _ _ V A C H E _ _ _
				// 8 _ _ _ _ _ P _ _ _ _ _ _
				// 9 _ _ _ _ _ _ _ _ _ _ _ _
				// Mettre un '_' pour les cases vides. Assurez-vous de respecter
				// l'alignement en utilisant String.format et n'oubliez pas les en-tetes
				// de lignes et de colonnes (chiffres).
			

		for (int i = 0; i < grille.length; i++) {
	        System.out.print((i + 1) + " "); 
	        
	        for (int j = 0; j < grille[i].length; j++) {
	            if (grille[i][j] == 0) {
	                System.out.print("_ "); //pour les cases vides
	            } else {
	                System.out.print(grille[i][j] + " ");
	            }
	        }
	        
	        System.out.println(); 
	    }
	}
		
	// TODO: Javadoc
	public static void afficheMots(String[] mots, int nbMots) {
		// Affiche la liste des mots contenus dans la grille sur une ligne.
		// La ligne debute par "Mots : " et chaque mot est separe par une virgule.
		// Assurez-vous de ne pas mettre de , a la fin et traitez une liste vide.
		// Exemple: Mots : patate, vache
		System.out.println("Mots :");
		for (int i = 0; i < mots.length; i++) {
			if (i==mots.length-1) {
				System.out.println(" " + mots[i]);
			} else {
				System.out.println(mots[i] + " , ");
			}
			
		}
	}

	// TODO: Javadoc
	// TODO: Tests unitaires
	public static int ajout(String[] vec, int nbElem, String elem) {
		// Fonction qui ajoute un element au bon endroit dans une liste (vec)
		// deja triee, s'il reste de la place. Elle retourne le nouveau
		// nombre d'elements dans la liste.
		if (nbElem < vec.length) {
			int curPos = nbElem;
			while (curPos > 0 && elem.compareTo(vec[curPos - 1]) < 0) {
				vec[curPos] = vec[curPos - 1];
				curPos--;
			}
			vec[curPos] = elem;
			nbElem++;
		}

		return nbElem;
	}

	// TODO: Javadoc
	// TODO: Tests unitaires
	public static int retrait(String[] vec, int nbElem, String elem) {
		// Fonction qui enleve un element dans une liste (vec) triee, s'il existe.
		// Pour trouver la position de l'element a retirer, vous devez appeler la
		// fonction rechercheBin. La fonction retourne le nouveau nombre
		// d'elements dans la liste.
		int posItem;
		posItem = rechercheBin(vec, nbElem, elem);
		if (posItem != -1) {
			nbElem--;
			for (int curPos = posItem; curPos < nbElem; curPos++) {
				vec[curPos] = vec[curPos + 1];
			}
			vec[nbElem] = "";

		}
		return nbElem;
	}

	// TODO: Javadoc
	// TODO: Tests unitaires
	public static void triSel(String[] vec, int nbElem) {
		// Tri les elements de la liste (vec) recue en parametre en utilisant
		// la methode de tri par selection. nbElem correspond au nombre
		// d'elements utilises (non nul) dans la liste.
		int posMin;
		String temp;
		for (int i = 0; i < nbElem; ++i) {
			posMin = i;
			for (int j = i + 1; j < nbElem; ++j) {
				if (vec[j].compareTo(vec[posMin]) < 0) {
					posMin = j;
				}
			}
			if (posMin != i) {
				temp = vec[i];
				vec[i] = vec[posMin];
				vec[posMin] = temp;
			}
		}
	}

	// TODO: Javadoc
	// TODO: Tests unitaires
	public static int rechercheBin(String[] vec, int nbElem, String valeur) {
		int posGa = 0;
		int posDr = nbElem - 1;
		int posMi = (posGa + posDr) / 2;
		while (posGa <= posDr && !valeur.equals(vec[posMi])) {
			if (valeur.compareTo(vec[posMi]) < 0) {
				posDr = posMi - 1;
			} else {
				posGa = posMi + 1;
			}
			posMi = (posGa + posDr) / 2;
			System.out.println(posGa + " : " + posMi + " : " + posDr);
		}
		if (posGa > posDr) {
			posMi = -1;
		}
		return posMi;
	}

	// TODO: Javadoc
	// TODO: Tests unitaires
	public static boolean motValide(String mot) {
		boolean test = false;
		// Permet de filtrer les mots du dictionnaire. La fonction doit
		// retourner true seulement si le mot contient uniquement les
		// caracteres minuscules a-z et qu'il a une longueur comprise
		// entre 4 et 12 caracteres inclusivement.
		if (mot.matches("[a-z]{4,12}")) {
			test = true;
		}
		return test;
	}

	// TODO: Javadoc
	public static int lireDictionnaire(String[] dictionnaire) {
		// Fonction qui permet de lire le fichier dictionnaire
		// src/<VotreNom>/TPRE/francais.txt . Ce fichier contient un mot
		// par ligne. Pour chacun des mots (lignes), vous devez le valider
		// a l'aide de la fonction motValide avant de l'ajouter au dictionnaire.
		// La fonction retourne le nombre de mots ajoutes au dictionnaire.
		// NOTE: Vous devez attraper les exceptions et vous devez fermer
		// le fichier correctement.
		int nbMots=0;
		BufferedReader reader = null;
		String ligne;
		try {
	        
	        reader = new BufferedReader(new FileReader("src/shamouni/TP04/francais.txt"));

	        
	        while ((ligne = reader.readLine()) != null) {
	            // Valider le mot
	            if (motValide(ligne) && dictionnaire.length>nbMots && !ligne.isEmpty()) {
	                // ajout du mot
	                dictionnaire[nbMots] = ligne;
	                nbMots++;
	            }
	        }
	    } catch (IOException e) {
	        //exception IOException
	        System.out.println("Erreur lors de la lecture du fichier dictionnaire : ");
	    } finally {
	       
	        if (reader != null) {
	            try {
	                reader.close();
	            } catch (IOException e) {
	               //exception IOException
	                System.out.println("Erreur lors de la fermeture du fichier dictionnaire : ");
	            }
	        }
	    }

	    return nbMots;
	}

	// TODO: Javadoc
	public static void ecrireGrille(char[][] grille, String[] mots, int nbMots) {
		// Fonction qui permet d'ecrire le fichier contenant la grille et les mots
		// a trouver (src/<VotreNom>/TPRE/grille.txt). Un exemple de fichier est
		// fourni avec le TP. Vous devez premierement ecrire la grille, soit un
		// ensemble de lettres majuscules separees par des espaces. Il y a un espace
		// apres chaque lettre, sauf pour la derniere de la ligne. A la suite de la
		// grille, vous devez laisser une ligne vide. Enfin, vous ecrivez la liste des
		// mots a trouver en ordre alphabetique, soit un mot par ligne.
		// NOTE: Vous devez attraper les exceptions et vous devez fermer
		// le fichier correctement.
		
		BufferedWriter writer = null;
		
		try {
			writer = new BufferedWriter(new FileWriter("src/shamouni/TP04/grille.txt"));
			
			for (int i = 0; i < grille.length; i++) {
	            for (int j = 0; j < grille[i].length; j++) {
	                writer.write(grille[i][j]);
	                if (j < grille[i].length - 1) {
	                    writer.write(" ");
	                }
	            }
	            writer.newLine(); // ligne vide
	            
			}
	            
	            for (int i = 0; i < nbMots; i++) { //ecrire les mots a trouver
	                writer.write(mots[i]);
	                writer.newLine();
	            }
	            
	        }  catch (IOException e) {
	            // Gérer l'exception IOException
	            System.out.println("Erreur lors de l'écriture du fichier grille");
		} finally {
			if (writer != null) {
				try {
					writer.close(); //fermeture du fichier
				} catch (IOException e) {
					System.out.println("Erreur lors de la fermeture du fichier grille : ");
				}
			}
		}
		
	}
	
}

