from datetime import datetime

class Mesure:
    def __init__(self, dateHeureMesure, description, distance):
        self.dateHeureMesure = dateHeureMesure
        self.description = description
        self.distance = distance

    def __repr__(self):
        # Représentation de l'objet dans une liste
        return f"{self.dateHeureMesure.strftime('%Y-%m-%d %H:%M:%S')} - {self.description}"

    def afficherMesure(self):
        # Retourne tous les attributs de l'objet
        return f"Date et heure: {self.dateHeureMesure.strftime('%Y-%m-%d %H:%M:%S')}\nDescription: {self.description}\nDonnées de la mesure: {self.distance}"
