import tkinter as tk
from tkinter import messagebox
from gpiozero import DistanceSensor, LED, Button
from time import sleep
import LCD1602 as LCD
import json
from datetime import datetime
from module4 import Mesure


capteur = DistanceSensor(echo=26, trigger=19, max_distance=33)
led_rouge = LED(6)
led_verte = LED(13)
btn_poussoir = Button(21)


LCD.init(0x27, 1)  

mesures_stockees = []


def demarrer_systeme():
    
    led_verte.on()
    led_rouge.off()
   
    LCD.clear()
    LCD.write(0, 0, "Systeme actif")
  
    description_entry.config(state=tk.NORMAL)
    
    statut_label.config(text="Actif", bg="green")


def arreter_systeme():
   
    led_rouge.on()
    led_verte.off()

    LCD.clear()
    LCD.write(0, 0, "Systeme arrete")
   
    description_entry.config(state=tk.DISABLED)
    
    statut_label.config(text="Inactif", bg="red")


def prendre_mesure():
   
    description = description_entry.get()
    if not description:
     
        LCD.clear()
        LCD.write(0, 0, "Manque de description")
        
        for _ in range(3):
            led_rouge.toggle()
            sleep(0.5)
        led_rouge.on()
        return

 
    distance = capteur.distance * 100  

   
    dateHeureMesure = datetime.now()
    mesure = Mesure(dateHeureMesure, description, distance)


    listbox.insert(tk.END, str(mesure))
    mesures_stockees.append(mesure)

   
    LCD.clear()
    LCD.write(0, 0, "Mesure prise")
    sleep(1)
    LCD.clear()
  
    LCD.write(0, 0, f"Distance: {distance:.2f} cm")


    for _ in range(3):
        led_verte.toggle()
        sleep(0.5)
    led_verte.on()


def sauvegarder_json():
    mesures = []
    for index in range(listbox.size()):
        mesure = mesures_stockees[index]
        mesures.append({
            "dateHeureMesure": mesure.dateHeureMesure.strftime('%Y-%m-%d %H:%M:%S'),
            "description": mesure.description,
            "distance" : mesure.distance
        })
    with open("mesures.json", "w") as f:
        json.dump(mesures, f, indent=4)
    messagebox.showinfo("Succès", "Mesures sauvegardées en JSON")


root = tk.Tk()
root.title("Système de captation")


demarrer_btn = tk.Button(root, text="Démarrer le système", command=demarrer_systeme)
demarrer_btn.pack()

arreter_btn = tk.Button(root, text="Arrêter le système", command=arreter_systeme)
arreter_btn.pack()


description_label = tk.Label(root, text="Description de la mesure:")
description_label.pack()
description_entry = tk.Entry(root, state=tk.DISABLED)
description_entry.pack()


listbox = tk.Listbox(root, height=10, width=50)
listbox.pack()

data_label = tk.Label(root, text="Données de la mesure:")
data_label.pack()
data_text = tk.Text(root, height=5, width=50)
data_text.pack()


def on_listbox_select(event):
    index = listbox.curselection()
    if index:
        mesure = mesures_stockees[index[0]]
        data_text.delete(1.0, tk.END)
        data_text.insert(tk.END, mesure.afficherMesure())

listbox.bind("<<ListboxSelect>>", on_listbox_select)


sauvegarder_btn = tk.Button(root, text="Sauvegarder JSON", command=sauvegarder_json)
sauvegarder_btn.pack()


statut_label = tk.Label(root, text="Inactif", bg="red")
statut_label.pack()

btn_poussoir.when_pressed = prendre_mesure


root.mainloop()
